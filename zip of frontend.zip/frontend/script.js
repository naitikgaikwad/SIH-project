const API_URL = "http://127.0.0.1:8000";


// ============================================================
// ELEMENTS
// ============================================================

const documentInput = document.getElementById("document");
const signatureInput = document.getElementById("signature");
const publicKeyInput = document.getElementById("publicKey");

const analyzeButton = document.getElementById("analyzeButton");
const loading = document.getElementById("loading");
const resultSection = document.getElementById("resultSection");


// ============================================================
// BUTTON EVENT
// ============================================================

analyzeButton.addEventListener("click", analyzeFiles);


// ============================================================
// FILE ANALYSIS
// ============================================================

async function analyzeFiles() {

    const documentFile = documentInput.files[0];
    const signatureFile = signatureInput.files[0];
    const publicKeyFile = publicKeyInput.files[0];


    // --------------------------------------------------------
    // CHECK FILES
    // --------------------------------------------------------

    if (!documentFile) {
        alert("Please select the document file.");
        return;
    }

    if (!signatureFile) {
        alert("Please select the digital signature file.");
        return;
    }

    if (!publicKeyFile) {
        alert("Please select the public key file.");
        return;
    }


    // --------------------------------------------------------
    // CREATE FORM DATA
    // --------------------------------------------------------

    const formData = new FormData();

    formData.append("document", documentFile);
    formData.append("signature", signatureFile);
    formData.append("public_key", publicKeyFile);


    // --------------------------------------------------------
    // LOADING STATE
    // --------------------------------------------------------

    loading.classList.remove("hidden");

    resultSection.classList.add("hidden");

    analyzeButton.disabled = true;


    try {

        // ----------------------------------------------------
        // SEND REQUEST
        // ----------------------------------------------------

        const response = await fetch(
            `${API_URL}/verify-and-detect`,
            {
                method: "POST",
                body: formData
            }
        );


        const data = await response.json();


        // ----------------------------------------------------
        // BACKEND ERROR
        // ----------------------------------------------------

        if (!response.ok) {

            throw new Error(
                data.detail || "Backend request failed."
            );

        }


        // ----------------------------------------------------
        // DISPLAY RESULT
        // ----------------------------------------------------

        displayResult(data.result);


    } catch (error) {

        console.error("Error:", error);

        alert(
            "Unable to connect to the backend.\n\n" +
            error.message
        );

    } finally {

        loading.classList.add("hidden");

        analyzeButton.disabled = false;

    }
}


// ============================================================
// DISPLAY RESULT
// ============================================================

function displayResult(result) {

    const ml = result.ml_detection;


    // --------------------------------------------------------
    // SHOW RESULT SECTION
    // --------------------------------------------------------

    resultSection.classList.remove("hidden");


    // --------------------------------------------------------
    // AUTHENTICATION
    // --------------------------------------------------------

    const authenticationStatus =
        document.getElementById(
            "signatureVerification"
        );

    const authenticationIcon =
        document.getElementById(
            "authenticationIcon"
        );


    authenticationStatus.textContent =
        result.signature_verification;


    document.getElementById(
        "algorithm"
    ).textContent =
        result.algorithm;


    document.getElementById(
        "hashAlgorithm"
    ).textContent =
        result.hash_algorithm;


    // --------------------------------------------------------
    // VALID / INVALID VISUAL STATE
    // --------------------------------------------------------

    if (
        result.signature_verification === "VALID"
    ) {

        authenticationIcon.textContent = "✓";

        authenticationIcon.style.background =
            "#e8f6ee";

        authenticationIcon.style.color =
            "#198754";

        authenticationStatus.style.color =
            "#198754";

    } else {

        authenticationIcon.textContent = "✕";

        authenticationIcon.style.background =
            "#fdebec";

        authenticationIcon.style.color =
            "#dc3545";

        authenticationStatus.style.color =
            "#dc3545";
    }


    // --------------------------------------------------------
    // ML PREDICTION
    // --------------------------------------------------------

    document.getElementById(
        "mlPrediction"
    ).textContent =
        ml.ml_prediction;


    document.getElementById(
        "threatProbability"
    ).textContent =
        `${ml.ml_threat_probability}%`;


    // --------------------------------------------------------
    // RISK SCORE
    // --------------------------------------------------------

    document.getElementById(
        "riskScore"
    ).textContent =
        `${ml.risk_score} / 100`;


    document.getElementById(
        "riskText"
    ).textContent =
        `${ml.risk_score} / 100`;


    const riskFill =
        document.getElementById("riskFill");


    riskFill.style.width =
        `${ml.risk_score}%`;


    // --------------------------------------------------------
    // THREAT LEVEL
    // --------------------------------------------------------

    document.getElementById(
        "threatLevel"
    ).textContent =
        ml.threat_level;


    // --------------------------------------------------------
    // ATTACK CATEGORY
    // --------------------------------------------------------

    document.getElementById(
        "attackCategory"
    ).textContent =
        ml.attack_category;


    // --------------------------------------------------------
    // INDICATORS
    // --------------------------------------------------------

    populateList(
        "indicators",
        ml.contributing_indicators
    );


    // --------------------------------------------------------
    // ASSESSMENT
    // --------------------------------------------------------

    document.getElementById(
        "assessment"
    ).textContent =
        ml.assessment;


    // --------------------------------------------------------
    // EXPLANATION
    // --------------------------------------------------------

    populateList(
        "explanation",
        ml.assessment_explanation
    );


    // --------------------------------------------------------
    // RECOMMENDATIONS
    // --------------------------------------------------------

    populateList(
        "recommendations",
        ml.recommended_action
    );


    // --------------------------------------------------------
    // SCROLL TO RESULTS
    // --------------------------------------------------------

    resultSection.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}


// ============================================================
// POPULATE RESULT LIST
// ============================================================

function populateList(elementId, items) {

    const list =
        document.getElementById(elementId);


    list.innerHTML = "";


    if (!items || items.length === 0) {

        const item =
            document.createElement("li");

        item.textContent =
            "None";

        list.appendChild(item);

        return;
    }


    items.forEach(text => {

        const item =
            document.createElement("li");

        item.textContent = text;

        list.appendChild(item);

    });
}